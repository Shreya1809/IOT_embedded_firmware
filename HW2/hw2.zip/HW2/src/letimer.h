/*
 * letimer.h
 *
 *  Created on: Jan 30, 2018
 *      Author: Shreya
 */


#ifndef LETIMER_H
#define LETIMER_H

#define PERIOD_MSEC 	(3000)            // on time OF LED in seconds
#define DUTY_CYCLE_MSEC (75)            //Period between LED0 consequent blinks in seconds

#include "em_cmu.h"      /* include statements */
#include "em_letimer.h"
#include "sleep.h"
#include "gpio.h"


unsigned int FreqofClock;                           //Variable to store current tree clock frequency

void LETIMER_init();							//function to initialize letimer


void LETIMER0_IRQHandler(void);						//function to handle interrupts



#endif /* SRC_LETIMER_H_ */
