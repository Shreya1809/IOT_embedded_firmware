/*
 * letimer.h
 *
 *  Created on: Jan 30, 2018
 *      Author: Shreya
 */


#ifndef LETIMER_H
#define LETIMER_H

#include "em_cmu.h"      /* include statements */
#include "em_letimer.h"
#include "sleep.h"
#include "gpio.h"


#define PERIOD_MSEC 		(2000)            // on time OF LED in seconds
#define DELAY_PERIOD_MSEC 	(18)            //Delay to be given after enabling the sensor for stabilization
#define LETIMER_EVENT     	(1)				// go through the scheduler
#define I2C_STAB_EVENT     	(2)			// go to sleep



unsigned int FreqofClock;                           //Variable to store current tree clock frequency

void LETIMER_init();							//function to initialize letimer


void LETIMER0_IRQHandler(void);						//function to handle interrupts



#endif /* SRC_LETIMER_H_ */
