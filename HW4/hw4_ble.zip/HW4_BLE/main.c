/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "ble-configuration.h"
#include "board_features.h"
#include "infrastructure.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"

/* Device initialization header */
#include "hal-config.h"

#if defined(HAL_CONFIG)
#include "bsphalconfig.h"
#else
#include "bspconfig.h"
#endif

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

#ifndef MAX_CONNECTIONS
#define MAX_CONNECTIONS 4
#endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

// Gecko configuration parameters (see gecko_configuration.h)
static const gecko_configuration_t config = {
  .config_flags = 0,
  .sleep.flags = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
  .bluetooth.max_connections = MAX_CONNECTIONS,
  .bluetooth.heap = bluetooth_stack_heap,
  .bluetooth.heap_size = sizeof(bluetooth_stack_heap),
  .bluetooth.sleep_clock_accuracy = 100, // ppm
  .gattdb = &bg_gattdb_data,
  .ota.flags = 0,
  .ota.device_name_len = 3,
  .ota.device_name_ptr = "OTA",
#if (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
  .pa.config_enable = 1, // Enable high power PA
  .pa.input = GECKO_RADIO_PA_INPUT_VBAT, // Configure PA input to VBAT
#endif // (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
};

// Flag for indicating DFU Reset must be performed
uint8_t boot_to_dfu = 0;
//***********************************************************************************
// Include files
//***********************************************************************************

#include <stdint.h>
#include <stdbool.h>

#include "main.h"
#include "gpio.h"
#include "sleep.h"
#include "letimer.h"
#include "cmu.h"
#include "I2C.h"
#include "si7021.h"
#include "lpm.h"
#include "em_core.h"
//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************
int8_t rssi;

//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************
void tempMeasureAndPush()
{
	uint8_t htmTempBuffer[5] = {0}; /* Stores the temperature data in the Health Thermometer (HTM) format. */
	uint8_t flags = 0x00;/* HTM flags set as 0 for Celsius, no time stamp and yes temperature type. */
	float  tempC = 0;     /* Stores the Temperature data read from the RHT sensor. */
	uint32_t temperature;   /* Stores the temperature data read from the sensor in the correct format */
	uint8_t *p = htmTempBuffer; /* Pointer to HTM temperature buffer needed for converting values to bitstream. */

	/* Convert flags to bitstream and append them in the HTM temperature data buffer (htmTempBuffer) */
	UINT8_TO_BITSTREAM(p, flags);
	if(TempSensor_Enabled())
	{
	  tempC = get_temp_si7021();

		if(tempC < TEMP_THRESHOLD)
		{
			CMU_ClockEnable(cmuClock_GPIO, true);
			GPIO_PinOutSet(LED1_port,LED1_pin);
		}
		/* Convert temperature to bitstream and place it in the HTM temperature data buffer (htmTempBuffer) */
		temperature = FLT_TO_UINT32(tempC*1000, -3);
		 UINT32_TO_BITSTREAM(p, temperature);
		    /* Send indication of the temperature in htmTempBuffer to all "listening" clients.
		     * This enables the Health Thermometer in the Blue Gecko app to display the temperature.
		     *  0xFF as connection ID will send indications to all connections. */
		 gecko_cmd_gatt_server_send_characteristic_notification( 0xFF, gattdb_temperature_measurement, 5, htmTempBuffer);
	}
}

//***********************************************************************************
// main
//***********************************************************************************

/**
 * @brief  Main function
 */

int main(void)
{
  // Initialize device
  initMcu();
  // Initialize board
  initBoard();

  // Initialize stack
  gecko_init(&config);

  // Initialize clocks
  CMU_init();
  CMU_LETIMER0_Init();

  /* Initialize GPIO */
  gpio_init();

  setup_I2C();
  LETIMER_init();




	while (1)
	{

		 /* Event pointer for handling events */
		    struct gecko_cmd_packet* evt;

		    /* Check for stack event. */
		    evt = gecko_wait_event();

		    /* Handle events */
		    switch (BGLIB_MSG_ID(evt->header))
		{
		      /* This boot event is generated when the system boots up after reset.
		       * Do not call any stack commands before receiving the boot event.
		       * Here the system is set to start advertising immediately after boot procedure. */
		      case gecko_evt_system_boot_id:
				gecko_cmd_system_set_tx_power(0);
		        /* Set advertising parameters. 337ms advertisement interval. All channels used.
		         * The first two parameters are minimum and maximum advertising interval, both in
		         * units of (milliseconds * 1.6). The third parameter '7' sets advertising on all channels. */
		        gecko_cmd_le_gap_set_adv_parameters(MIN_ADVERTISING_INTERVAL_COUNT, MAX_ADVERTISING_INTERVAL_COUNT,  7);

		        /* Start general advertising and enable connections. */
		        gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
		        
		        break;


		      case gecko_evt_le_connection_closed_id:

		        /* Check if need to boot to dfu mode */
		        if (boot_to_dfu) {
		          /* Enter to DFU OTA mode */
		          gecko_cmd_system_reset(2);
		        } else {
		        gecko_cmd_system_set_tx_power(0);
		          /* Restart advertising after client has disconnected */
		          gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
		        }
		        break;


		      case gecko_evt_le_connection_opened_id:

		          	  gecko_cmd_le_connection_set_parameters(evt->data.evt_le_connection_opened.connection,
		          			  	  	  	  	  	  	  	  	  MIN_CONNECTION_INTERVAL_COUNT,
		      												  MAX_CONNECTION_INTERVAL_COUNT,
		      												  SLAVE_LATENCY,
		      												  CONNECTION_TIMEOUT_MS);

		          	  break;

		      /* Events related to OTA upgrading
		         ----------------------------------------------------------------------------- */

		      /* Check if the user-type OTA Control Characteristic was written.
		       * If ota_control was written, boot the device into Device Firmware Upgrade (DFU) mode. */
		      case gecko_evt_gatt_server_user_write_request_id:

		        if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control) {
		          /* Set flag to enter to OTA mode */
		          boot_to_dfu = 1;
		          /* Send response to Write Request */
		          gecko_cmd_gatt_server_send_user_write_response(
		            evt->data.evt_gatt_server_user_write_request.connection,
		            gattdb_ota_control,
		            bg_err_success);

		          /* Close connection to enter to DFU OTA mode */
		          gecko_cmd_endpoint_close(evt->data.evt_gatt_server_user_write_request.connection);
		        }
		        break;


		      case gecko_evt_gatt_server_characteristic_status_id:
		    	  //if (evt-> data.evt_gatt_server_characteristic_status.status_flags == gatt_server_confirmation)
		    	      	  {
		    	      		  gecko_cmd_le_connection_get_rssi(evt-> data.evt_gatt_server_characteristic_status.connection);
		    	      	  }
		    	          break;
		              break;


		      case gecko_evt_system_external_signal_id:
		    	  if((evt->data.evt_system_external_signal.extsignals & I2C_STAB_EVENT) != 0)
				  {
					if(TempSensor_Enabled())
					{
						LoadPowerON();
						tempMeasureAndPush();
						LoadPowerOFF();
					}
					CORE_AtomicDisableIrq();
					Schedule_event &= ~I2C_STAB_EVENT;
					CORE_AtomicEnableIrq();
				  }
		    	  if((evt->data.evt_system_external_signal.extsignals & LETIMER_EVENT) != 0)
		    	  {
		    		GPIO_PinModeSet(gpioPortD, 9, gpioModePushPull,1) ;
		    		CORE_AtomicDisableIrq();
		    		Schedule_event &= ~LETIMER_EVENT;
		    		CORE_AtomicEnableIrq();
		    	  }


		    	  break;


		      case gecko_evt_le_connection_rssi_id:


		      			rssi = evt->data.evt_le_connection_rssi.rssi;
		      			struct gecko_msg_system_set_tx_power_rsp_t *tx_rsp;
		      			if(rssi > -35)
		      				tx_rsp = gecko_cmd_system_set_tx_power(TX_MIN);
		      			else if(( rssi < -35 ) && (rssi > -45))
		      				tx_rsp = gecko_cmd_system_set_tx_power(-200);
		      			else if((rssi < -45 ) && (rssi > -55))
		      				tx_rsp = gecko_cmd_system_set_tx_power(-150);
		      			else if((rssi < -55) && (rssi > -65))
		      				tx_rsp = gecko_cmd_system_set_tx_power(-50);
		      			else if((rssi < -65) && (rssi > -75))
		      				tx_rsp = gecko_cmd_system_set_tx_power(0);
		      			else if((rssi < -75) && (rssi > -85))
		      				tx_rsp = gecko_cmd_system_set_tx_power(50);
		      			else
		      				tx_rsp = gecko_cmd_system_set_tx_power(TX_MAX);
		      			int16 power = tx_rsp->set_power;
		      			break;
		      default:
		        break;
		    }
	}

	}






/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
