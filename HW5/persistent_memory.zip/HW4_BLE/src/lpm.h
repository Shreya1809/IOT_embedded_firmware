/*
 * lpm.h
 *
 *  Created on: Feb 9, 2018
 *      Author: Shreya
 */

#ifndef LPM_H_
#define LPM_H_

void LoadPowerON();
void LoadPowerOFF();


#endif /* LPM_H_ */
